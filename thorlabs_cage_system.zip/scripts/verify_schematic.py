#!/usr/bin/env python3
"""Verify geometry, retained source primitives, labels and raster output."""
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from PIL import Image

import build_schematic as builder

ROOT = Path(__file__).resolve().parents[1]
S = builder.s
SVG_FILE = ROOT / "thorlabs_cage_system.svg"
PNG_FILE = ROOT / "thorlabs_cage_system.png"
svg = ET.parse(SVG_FILE).getroot()
manifest = json.loads((ROOT / "components/ATTRIBUTION.json").read_text())
checks = []


def check(description, passed):
    if not passed:
        raise AssertionError(description)
    checks.append(description)


def transform_point(point, spec):
    x, y = (point[i] - spec["source_optical_center"][i] for i in (0, 1))
    if spec["reflected_horizontally"]:
        x = -x
    angle = math.radians(spec["rotation_degrees"])
    x, y = x * math.cos(angle) - y * math.sin(angle), x * math.sin(angle) + y * math.cos(angle)
    return tuple(spec["optical_center"][i] + spec["uniform_scale"] * v for i, v in enumerate((x, y)))


def close(a, b):
    return math.dist(a, b) < 1e-8


groups = list(svg.find(f"{S('g')}[@id='components']"))
instances = manifest["layout"]["components"]
check("Exactly 13 directly embedded component groups in beam order", len(groups) == len(instances) == 13)
check("Component inventory: two launches, four mirrors, two irises, two polarizers, two half-wave plates and one quarter-wave plate",
      Counter(x["asset"] for x in instances) == {"fiber": 2, "mirror": 4, "iris": 2, "polarizer": 2, "hwp": 2, "qwp": 1})

pitch_x = manifest["layout"]["horizontal_pitch"]
pitch_y = manifest["layout"]["vertical_pitch"]
check("Equal horizontal and vertical grid pitch: 190 SVG units", pitch_x == pitch_y == 190)
for group, spec, expected in zip(groups, instances, builder.LAYOUT):
    key, label, col, row, angle, reflected = expected
    check(f"{spec['id']}: correct asset, grid location, true optical center and placement transform",
          spec["asset"] == key and spec["label"] == label and spec["column"] == col and spec["row"] == row
          and group.get("transform") == spec["transform"]
          and close(transform_point(spec["source_optical_center"], spec),
                    [440 + col * pitch_x, 180 + row * pitch_y]))
    selected, _ = builder.selected_art(key)
    retained = [node for node in group if node.tag != S("defs")]
    check(f"{spec['id']}: all required source component elements retained", len(selected) == len(retained))
    for (_, original), imported in zip(selected, retained):
        old = dict(original.attrib)
        new = dict(imported.attrib)
        new.pop("id")
        if reflected and imported.tag == S("text"):
            check(f"{spec['id']}: intrinsic {imported.text!r} text remains upright",
                  new.pop("transform") == f"translate({builder.number(2 * float(old['x']))} 0) scale(-1 1)")
        for attr in old:
            new[attr] = re.sub(r"url\(#" + re.escape(spec["id"]) + r"-([^)]*)\)", r"url(#\1)", new[attr])
        check(f"{imported.get('id')}: source geometry, styling and marking preserved",
              old == new and original.tag == imported.tag and original.text == imported.text)

labels = list(svg.find(f"{S('g')}[@id='component-labels']"))
check("All 13 visible labels exactly match the requested sequence", [x.text for x in labels] == [x[1] for x in builder.LAYOUT])
for spec, label in zip(instances, labels):
    check(f"{spec['id']}: label placed at its recorded anchor",
          close([float(label.get('x')), float(label.get('y'))], spec["label_anchor"]))
    if spec["asset"] in {"polarizer", "hwp", "qwp"}:
        check(f"{spec['id']}: mount label is below its optic", float(label.get('y')) > spec["optical_center"][1] + 41)

for spec in instances:
    if spec["asset"] == "fiber":
        lens = transform_point([46.5, 27], spec)
        body = transform_point([85, 27], spec)
        check(f"{spec['id']}: free-space side faces into the system",
              body[0] < lens[0] if spec["column"] == 0 else body[0] > lens[0])

expected_d = "M 440 180 H 630 V 370 H 2150 V 180 H 2340"
beam_group = svg.find(f"{S('g')}[@id='optical-path']")
check("Single continuous beam follows east, south, east, north, east",
      beam_group.find(f"{S('path')}[@id='continuous-beam']").get("d") == expected_d)
check("Beam is behind all component artwork", list(svg).index(beam_group) < list(svg).index(svg.find(f"{S('g')}[@id='components']")))
arrows = beam_group.findall(S("line"))
check("Exactly 12 directional arrowheads, one in every component gap", len(arrows) == 12)
for arrow, a, b in zip(arrows, instances, instances[1:]):
    ax, ay = a["optical_center"]
    bx, by = b["optical_center"]
    x1, y1, x2, y2 = (float(arrow.get(attr)) for attr in ("x1", "y1", "x2", "y2"))
    check(f"{arrow.get('id')}: direction and midpoint agree with the beam",
          abs((x2-x1) * (by-ay) - (y2-y1) * (bx-ax)) < 1e-8
          and (x2-x1) * (bx-ax) + (y2-y1) * (by-ay) > 0
          and close([x2 + 2.3 * (bx-ax) / 190, y2 + 2.3 * (by-ay) / 190], [(ax+bx)/2, (ay+by)/2])
          and arrow.get("marker-end") == "url(#library-beam-arrow)")

for index, spec in enumerate(instances):
    if spec["asset"] != "mirror":
        continue
    p = transform_point([50, 15], spec)
    q = transform_point([75, 55], spec)
    dx, dy = q[0]-p[0], q[1]-p[1]
    check(f"{spec['id']}: exact 45-degree mirror surface in {spec['surface_orientation']} orientation",
          abs(abs(dx)-abs(dy)) < 1e-8 and (dx*dy > 0) == (spec["surface_orientation"] == "\\"))
    length = math.hypot(dx, dy)
    tx, ty = dx / length, dy / length
    center = spec["optical_center"]
    incoming = [center[j] - instances[index-1]["optical_center"][j] for j in (0, 1)]
    outgoing = [instances[index+1]["optical_center"][j] - center[j] for j in (0, 1)]
    projection = incoming[0]*tx + incoming[1]*ty
    check(f"{spec['id']}: specular reflection gives an exact 90-degree beam turn",
          close([2*projection*tx-incoming[0], 2*projection*ty-incoming[1]], outgoing))
    # Check every source hatch endpoint: it must face away from both ray legs.
    native = builder.source("mirror")
    hatch_lines = [e for e in native if e.tag == S("line") and e.get("stroke") == "#666666"]
    for hatch in hatch_lines:
        a = transform_point([float(hatch.get("x1")), float(hatch.get("y1"))], spec)
        b = transform_point([float(hatch.get("x2")), float(hatch.get("y2"))], spec)
        backing = [b[j]-a[j] for j in (0, 1)]
        front_in = [-v for v in incoming]
        check(f"{spec['id']}: hatch at source y={hatch.get('y1')} is on the backing side",
              sum(backing[j]*front_in[j] for j in (0,1)) < 0
              and sum(backing[j]*outgoing[j] for j in (0,1)) < 0)

source_marker = builder.source("mirror").find(f"{S('defs')}/{S('marker')}[@id='arrowhead-beam']")
master_marker = svg.find(f"{S('defs')}/{S('marker')}[@id='library-beam-arrow']")
original_attrs, master_attrs = dict(source_marker.attrib), dict(master_marker.attrib)
original_attrs.pop("id")
master_attrs.pop("id")
check("Library beam-arrow marker geometry, attributes and red color preserved",
      original_attrs == master_attrs and source_marker[0].tag == master_marker[0].tag
      and source_marker[0].attrib == master_marker[0].attrib)

ids = [node.get("id") for node in svg.iter() if node.get("id")]
check("All imported IDs are unique", len(ids) == len(set(ids)))
refs = [ref for node in svg.iter() for value in node.attrib.values() for ref in re.findall(r"url\(#([^)]*)\)", value)]
check("All local ID references resolve", all(ref in ids for ref in refs))
check("No image, use, foreignObject, script, external font or raster dependency",
      all(node.tag not in {S("image"), S("use"), S("foreignObject"), S("script"), S("style")} for node in svg.iter())
      and all("href" not in attr and "data:image" not in value for node in svg.iter()
              for attr, value in node.attrib.items()))
texts = [node.text for node in svg.iter(S("text"))]
check("Waveplate λ/2 and λ/4 markings remain editable SVG text", texts.count("λ/2") == 2 and texts.count("λ/4") == 1)
check("No standalone source captions, optic abbreviations, numbers, title or footer",
      Counter(texts) == Counter([x[1] for x in builder.LAYOUT] + ["λ/2", "λ/4", "λ/2"]))
check("Both fiber launches omit x/y reference labels, axis arrows and stage text",
      all([node.tag for node in group] == [S("path"), S("rect"), S("line")]
          for group in groups if group.get("data-asset") == "fiber"))

embedded = json.loads(svg.find(f"{S('metadata')}[@id='provenance']/{S('metadata')}[@id='asset-attribution-manifest']").text)
check("Embedded metadata matches the accompanying attribution manifest", embedded == manifest)
check("Manifest contains pinned revision, source paths, adaptations and CC BY 4.0 attribution",
      manifest["library"]["revision"] == builder.REVISION and manifest["library"]["license"] == "CC BY 4.0"
      and builder.LICENSE in manifest["required_attribution"]
      and all(asset["repository_path"] and asset["adaptations"] for asset in manifest["assets"]))
for asset in manifest["assets"]:
    check(f"{asset['local_file']}: source file hash matches the pinned download",
          sha256((ROOT / asset["local_file"]).read_bytes()).hexdigest() == asset["source_sha256"])
check("Original library license retained", sha256((ROOT / "components/LICENSE").read_bytes()).hexdigest() == manifest["library"]["license_sha256"])

image = Image.open(PNG_FILE)
check("PNG width exceeds 6000 pixels and dimensions match the recorded render", image.size == (7200, 1502))
check("PNG has an embedded sRGB profile and 600 dpi resolution", bool(image.info.get("icc_profile")) and all(abs(d - 600) < 0.02 for d in image.info["dpi"]))
image = image.convert("RGB")
check("PNG is opaque white in all generous outer margins", all(image.getpixel(p) == (255,255,255)
      for p in [(0,0), (7199,0), (0,1501), (7199,1501), (3600,30), (3600,1471), (30,750), (7170,750)]))
check("PNG contains no artwork clipped at any edge", image.crop((0,0,7200,10)).getextrema() == ((255,255),)*3
      and image.crop((0,1492,7200,1502)).getextrema() == ((255,255),)*3
      and image.crop((0,0,10,1502)).getextrema() == ((255,255),)*3
      and image.crop((7190,0,7200,1502)).getextrema() == ((255,255),)*3)

report = {
    "result": "PASS", "checks_passed": len(checks), "checks": checks,
    "master_svg_sha256": sha256(SVG_FILE.read_bytes()).hexdigest(),
    "png_sha256": sha256(PNG_FILE.read_bytes()).hexdigest(),
    "png_dimensions": list(image.size), "render": json.loads((ROOT / ".tmp.codex/render-info.json").read_text()),
}
(ROOT / "components/VERIFICATION.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(f"PASS: {len(checks)} geometry, source fidelity, packaging and raster checks.")

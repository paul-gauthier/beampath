#!/usr/bin/env python3
"""Assemble actual, unmodified primitive artwork from pinned library SVGs."""
from copy import deepcopy
from hashlib import sha256
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SVG = "http://www.w3.org/2000/svg"
RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
CC = "http://creativecommons.org/ns#"
DC = "http://purl.org/dc/elements/1.1/"
for prefix, uri in [("", SVG), ("rdf", RDF), ("cc", CC), ("dc", DC)]:
    ET.register_namespace(prefix, uri)

REVISION = "7e44e14341489b067d7c8e1390af87b9c423103e"
REPOSITORY = "https://github.com/itgall/photonics-component-library"
LICENSE = "https://creativecommons.org/licenses/by/4.0/"
ATTRIBUTION = (
    "Component artwork: Photonics Component Library (2025), "
    "Photonics Component Library Contributors, maintained by Isaac Gallegos (itgall). "
    f"{REPOSITORY}. Licensed under Creative Commons Attribution 4.0 International "
    f"({LICENSE}). Adapted for this schematic: source captions and demonstration beams "
    "removed; fiber-launch reference axes and stage text removed; "
    "component elements translated, uniformly scaled, rotated or reflected; IDs namespaced; "
    "new continuous optical path, arrows and mount labels added. "
    "No endorsement by the library contributors or Thorlabs is implied."
)
ASSETS = {
    "fiber": {
        "path": "fiber-optics/flat_2d/svg/11_beam_delivery/f-fiber-launch.svg",
        "center": [46.5, 27], "scale": 2.4, "caption": "Fiber launch",
        "center_basis": "Intersection of the lens's cubic Bezier curve with the optical axis at y=27 (t=0.5).",
    },
    "mirror": {
        "path": "free-space-optics/flat_2d/svg/14_flat_mirrors/fs-flat-mirror.svg",
        "center": [62.5, 35], "scale": 1.6, "caption": "Flat mirror",
        "center_basis": "Midpoint of the actual reflecting line from (50,15) to (75,55).",
    },
    "iris": {
        "path": "free-space-optics/flat_2d/svg/23_apertures_beam_control/fs-iris.svg",
        "center": [50, 40], "scale": 1.5, "caption": "Iris diaphragm",
        "center_basis": "Concentric iris circles and aperture center.",
    },
    "polarizer": {
        "path": "free-space-optics/flat_2d/svg/17_polarizers/fs-wire-grid-polarizer.svg",
        "center": [49, 35], "scale": 1.5, "caption": "Wire-grid polarizer",
        "center_basis": "Center of the optical plate rectangle x=45..53, y=8..62.",
    },
    "hwp": {
        "path": "free-space-optics/flat_2d/svg/17_waveplates/fs-hwp.svg",
        "center": [54, 35], "scale": 1.5, "caption": "Half-wave plate",
        "center_basis": "Center of the optical plate rectangle x=50..58, y=10..60.",
    },
    "qwp": {
        "path": "free-space-optics/flat_2d/svg/17_waveplates/fs-qwp.svg",
        "center": [54, 35], "scale": 1.5, "caption": "Quarter-wave plate",
        "center_basis": "Center of the optical plate rectangle x=50..58, y=10..60.",
    },
}

PITCH = 190
ORIGIN = [440, 180]
WIDTH, HEIGHT = 2780, 580
STOCK_ANGLE = math.degrees(math.atan2(40, 25))
LAYOUT = [
    ("fiber", "KT120", 0, 0, 0, True),
    ("mirror", "Corner mirror", 1, 0, 225 - STOCK_ANGLE, False),
    ("mirror", "Corner mirror", 1, 1, 45 - STOCK_ANGLE, False),
    ("iris", "Iris", 2, 1, 0, False),
    ("polarizer", "CRM1PT", 3, 1, 0, False),
    ("hwp", "K10CR1", 4, 1, 0, False),
    ("qwp", "DDR25", 5, 1, 0, False),
    ("hwp", "DDR25", 6, 1, 0, False),
    ("polarizer", "CRM1PT", 7, 1, 0, False),
    ("iris", "Iris", 8, 1, 0, False),
    ("mirror", "Corner mirror", 9, 1, -45 - STOCK_ANGLE, False),
    ("mirror", "Corner mirror", 9, 0, 135 - STOCK_ANGLE, False),
    ("fiber", "KT120", 10, 0, 0, False),
]


def s(tag):
    return f"{{{SVG}}}{tag}"


def element(parent, tag, **attrs):
    return ET.SubElement(parent, s(tag), {k.replace("_", "-"): str(v) for k, v in attrs.items()})


def number(v):
    return f"{v:.12g}"


def source(key):
    return ET.parse(ROOT / "components" / Path(ASSETS[key]["path"]).name).getroot()


def selected_art(key):
    """Omit captions, demo beams and fiber-launch reference annotations."""
    selected, omitted = [], []
    for index, child in enumerate(source(key)):
        if child.tag == s("defs"):
            continue
        if child.tag == s("text") and child.text == ASSETS[key]["caption"]:
            omitted.append({"source_child_index": index, "reason": "standalone caption"})
        elif child.tag == s("line") and child.get("stroke") == "#CC0000" and not child.get("stroke-dasharray"):
            omitted.append({"source_child_index": index, "reason": "demonstration beam segment"})
        elif key == "fiber" and child.tag == s("text") and child.text in {"stage", "x", "y"}:
            omitted.append({"source_child_index": index, "reason": "fiber-launch reference annotation"})
        elif key == "fiber" and child.tag == s("line") and child.get("stroke") == "#444444":
            omitted.append({"source_child_index": index, "reason": "fiber-launch reference axis arrow"})
        else:
            selected.append((index, deepcopy(child)))
    return selected, omitted


def namespace_ids(node, mapping):
    for child in node.iter():
        for key, value in list(child.attrib.items()):
            if key == "id" and value in mapping:
                child.set(key, mapping[value])
            else:
                value = re.sub(r"url\(#([^)]*)\)", lambda m: f"url(#{mapping.get(m[1], m[1])})", value)
                if value.startswith("#") and value[1:] in mapping:
                    value = "#" + mapping[value[1:]]
                child.set(key, value)


def build():
    svg = ET.Element(s("svg"), {
        "version": "1.1", "width": str(WIDTH), "height": str(HEIGHT),
        "viewBox": f"0 0 {WIDTH} {HEIGHT}",
        "font-family": "Helvetica, Arial, sans-serif",
        "aria-label": "Optical path through thirteen components in a folded two-row cage system",
    })
    metadata = element(svg, "metadata", id="provenance")
    rdf = ET.SubElement(metadata, f"{{{RDF}}}RDF")
    work = ET.SubElement(rdf, f"{{{CC}}}Work", {f"{{{RDF}}}about": ""})
    ET.SubElement(work, f"{{{DC}}}source", {f"{{{RDF}}}resource": f"{REPOSITORY}/tree/{REVISION}"})
    ET.SubElement(work, f"{{{DC}}}rights").text = "Copyright (c) 2025 Photonics Component Library Contributors"
    ET.SubElement(work, f"{{{CC}}}license", {f"{{{RDF}}}resource": LICENSE})
    ET.SubElement(work, f"{{{CC}}}attributionName").text = "Photonics Component Library Contributors"
    ET.SubElement(work, f"{{{CC}}}attributionURL", {f"{{{RDF}}}resource": REPOSITORY})
    ET.SubElement(work, f"{{{DC}}}description").text = ATTRIBUTION
    manifest_meta = element(metadata, "metadata", id="asset-attribution-manifest")
    defs = element(svg, "defs")
    marker = deepcopy(source("mirror").find(f"{s('defs')}/{s('marker')}[@id='arrowhead-beam']"))
    marker.set("id", "library-beam-arrow")
    defs.append(marker)
    element(svg, "rect", id="white-background", x=0, y=0, width=WIDTH, height=HEIGHT, fill="#FFFFFF")

    beam = element(svg, "g", id="optical-path", fill="none", stroke="#CC0000", stroke_width=2.3,
                   stroke_linecap="butt", stroke_linejoin="miter")
    positions = [(ORIGIN[0] + PITCH * col, ORIGIN[1] + PITCH * row) for _, _, col, row, _, _ in LAYOUT]
    element(beam, "path", id="continuous-beam", d="M 440 180 H 630 V 370 H 2150 V 180 H 2340")
    for index, ((ax, ay), (bx, by)) in enumerate(zip(positions, positions[1:]), 1):
        # refX=5 and polygon's tip x=6 put the tip one beam width after the endpoint.
        ux, uy = (bx - ax) / PITCH, (by - ay) / PITCH
        mx, my = (ax + bx) / 2, (ay + by) / 2
        ex, ey = mx - 2.3 * ux, my - 2.3 * uy
        element(beam, "line", id=f"beam-arrow-{index:02d}",
                x1=number(ex - 12 * ux), y1=number(ey - 12 * uy), x2=number(ex), y2=number(ey),
                marker_end="url(#library-beam-arrow)")

    components = element(svg, "g", id="components")
    labels = element(svg, "g", id="component-labels", font_family="Helvetica, Arial, sans-serif",
                     font_size=23, font_weight="normal", text_anchor="middle", fill="#000000")
    instances = []
    for index, (key, label, col, row, angle, reflected) in enumerate(LAYOUT, 1):
        asset = ASSETS[key]
        cx, cy = asset["center"]
        x, y = positions[index - 1]
        name = f"optic-{index:02d}"
        transform = f"translate({x} {y}) rotate({number(angle)}) scale({asset['scale']})"
        if reflected:
            transform += " scale(-1 1)"
        transform += f" translate({number(-cx)} {number(-cy)})"
        group = element(components, "g", id=name, transform=transform,
                        data_asset=key, data_column=col, data_row=row,
                        data_optical_center=f"{x} {y}", data_source_center=f"{cx} {cy}")
        src = source(key)
        for attr in ["font-family", "fill", "stroke"]:
            if attr in src.attrib:
                group.set(attr, src.attrib[attr])
        selected, omitted = selected_art(key)
        references = {m for _, child in selected for node in child.iter()
                      for value in node.attrib.values() for m in re.findall(r"url\(#([^)]*)\)", value)}
        mapping = {node.get("id"): f"{name}-{node.get('id')}" for node in src.iter() if node.get("id")}
        if references:
            imported_defs = element(group, "defs")
            for child in src.find(s("defs")):
                if child.get("id") in references:
                    copied = deepcopy(child)
                    namespace_ids(copied, mapping)
                    imported_defs.append(copied)
        for child_index, child in selected:
            namespace_ids(child, mapping)
            child.set("id", f"{name}-source-{child_index:02d}")
            if reflected and child.tag == s("text"):
                # Reflect glyphs a second time at their source anchor, without moving it.
                anchor = float(child.get("x"))
                child.set("transform", f"translate({number(2 * anchor)} 0) scale(-1 1)")
            group.append(child)
        label_x = x
        if key == "fiber":
            # Label the translation-stage body; optical center stays on the lens.
            label_x += (-1 if reflected else 1) * asset["scale"] * (85 - cx)
        label_y = y - 73 if row == 0 else y + 97
        element(labels, "text", id=f"{name}-label", x=number(label_x), y=number(label_y)).text = label
        instance = {
            "id": name, "asset": key, "label": label, "column": col, "row": row,
            "optical_center": [x, y], "source_optical_center": [cx, cy],
            "uniform_scale": asset["scale"], "rotation_degrees": angle,
            "reflected_horizontally": reflected, "transform": transform,
            "label_anchor": [label_x, label_y],
            "retained_source_child_indices": [i for i, _ in selected], "omitted_elements": omitted,
        }
        if key == "mirror":
            instance["surface_orientation"] = "\\" if col == 1 else "/"
            instance["backing_direction"] = {
                (1, 0): "northeast", (1, 1): "southwest", (9, 1): "southeast", (9, 0): "northwest",
            }[(col, row)]
        instances.append(instance)

    assets = []
    for key, asset in ASSETS.items():
        file = ROOT / "components" / Path(asset["path"]).name
        _, omitted = selected_art(key)
        assets.append({
            "key": key, "local_file": f"components/{file.name}", "repository_path": asset["path"],
            "source_url": f"https://raw.githubusercontent.com/itgall/photonics-component-library/{REVISION}/{asset['path']}",
            "source_sha256": sha256(file.read_bytes()).hexdigest(),
            "source_optical_center": asset["center"], "center_basis": asset["center_basis"],
            "adaptations": [
                "Original source SVG preserved byte-for-byte in components/.",
                "Actual source component primitives embedded directly in editable SVG groups.",
                "Standalone caption and demonstration beam segments omitted from assembled artwork.",
                "Geometry, colors, strokes and intrinsic markings preserved; placement uses only similarity transforms.",
            ] + (["Fiber-launch x/y reference labels, axis arrows and stage text omitted; lens, stage body and fiber retained."]
                 if key == "fiber" else [])
              + (["Intrinsic red dashed fast-axis line and editable λ notation retained."] if key in ("hwp", "qwp") else []),
            "omitted_elements": omitted,
        })
    manifest = {
        "schema_version": 1, "figure": "thorlabs_cage_system.svg", "created": "2026-10-02",
        "library": {
            "name": "Photonics Component Library", "repository": REPOSITORY, "revision": REVISION,
            "revision_url": f"{REPOSITORY}/commit/{REVISION}", "style": "flat_2d",
            "copyright": "Copyright (c) 2025 Photonics Component Library Contributors",
            "license": "CC BY 4.0", "license_url": LICENSE, "license_file": "components/LICENSE",
            "license_sha256": sha256((ROOT / "components/LICENSE").read_bytes()).hexdigest(),
        },
        "required_attribution": ATTRIBUTION,
        "reuse_instruction": "Retain this attribution and the license link with the SVG; when using the PNG or publishing the figure, include the attribution in the accompanying publication, credits or asset records. Indicate any further changes.",
        "assets": assets,
        "marker": {
            "source_path": ASSETS["mirror"]["path"], "source_id": "arrowhead-beam",
            "master_id": "library-beam-arrow", "adaptation": "ID renamed only; marker geometry and color preserved.",
        },
        "layout": {
            "viewbox": [0, 0, WIDTH, HEIGHT], "grid_origin": ORIGIN,
            "horizontal_pitch": PITCH, "vertical_pitch": PITCH,
            "beam_direction_sequence": ["east", "south", "east", "north", "east"],
            "beam_color": "#CC0000", "beam_width": 2.3, "continuous_beam_id": "continuous-beam",
            "arrow_count": 12, "components": instances,
        },
        "render": {"file": "thorlabs_cage_system.png", "width_pixels": 7200, "height_pixels": 1502,
                   "resolution_dpi": 600,
                   "method": "Render the finished master SVG with sharp/libvips/librsvg; white background; sRGB PNG."},
    }
    manifest_meta.text = json.dumps(manifest, ensure_ascii=False, indent=2)
    ET.indent(svg, space="  ")
    ET.ElementTree(svg).write(ROOT / "thorlabs_cage_system.svg", encoding="utf-8", xml_declaration=True)
    (ROOT / "components/ATTRIBUTION.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    (ROOT / "components/ATTRIBUTION.txt").write_text(ATTRIBUTION + "\n\n" + manifest["reuse_instruction"] + "\n")
    print(f"Created {WIDTH} × {HEIGHT} vector schematic with {len(instances)} directly embedded components.")


if __name__ == "__main__":
    build()

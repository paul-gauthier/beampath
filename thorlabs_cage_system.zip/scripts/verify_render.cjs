// Verify the delivered PNG against a fresh rasterization of the finished SVG.
const fs = require('fs');
const path = require('path');
let sharp;
try { sharp = require('sharp'); }
catch (_) {
  sharp = require('/Users/paul/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
}
const root = path.resolve(__dirname, '..');
(async () => {
  const source = fs.readFileSync(path.join(root, 'thorlabs_cage_system.svg'));
  const reference = await sharp(source, {density: 7200 / 2780 * 72})
    .resize({width: 7200}).flatten({background: '#ffffff'}).withIccProfile('srgb')
    .raw().toBuffer();
  const delivered = await sharp(path.join(root, 'thorlabs_cage_system.png')).removeAlpha().raw().toBuffer();
  if (!reference.equals(delivered)) throw new Error('PNG pixels differ from finished SVG render');
  const file = path.join(root, 'components/VERIFICATION.json');
  const report = JSON.parse(fs.readFileSync(file));
  const check = 'Delivered PNG decoded pixels exactly match a fresh render of the finished SVG';
  if (!report.checks.includes(check)) {
    report.checks.push(check);
    report.checks_passed += 1;
  }
  fs.writeFileSync(file, JSON.stringify(report, null, 2) + '\n');
  console.log('PASS: PNG exactly matches fresh master SVG render.');
})().catch(error => {console.error(error); process.exit(1);});

// Render the finished SVG; never composite separate component images.
const fs = require('fs');
const path = require('path');
let sharp;
try { sharp = require('sharp'); }
catch (_) {
  sharp = require('/Users/paul/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
}
const root = path.resolve(__dirname, '..');
(async () => {
  const source = fs.readFileSync(path.join(root, 'thorlabs_cage_system.svg'));
  const result = await sharp(source, {density: 7200 / 2780 * 72})
    .resize({width: 7200})
    .flatten({background: '#ffffff'})
    .withMetadata({density: 600})
    .withIccProfile('srgb')
    .png({compressionLevel: 9})
    .toFile(path.join(root, 'thorlabs_cage_system.png'));
  fs.mkdirSync(path.join(root, '.tmp.codex'), {recursive: true});
  await sharp(source, {density: 144})
    .resize({width: 2000})
    .flatten({background: '#ffffff'})
    .png().toFile(path.join(root, '.tmp.codex/figure-preview.png'));
  const metadata = {width: result.width, height: result.height, bytes: result.size, density: 600,
    sharp: sharp.versions.sharp, librsvg: sharp.versions.rsvg};
  fs.writeFileSync(path.join(root, '.tmp.codex/render-info.json'), JSON.stringify(metadata, null, 2) + '\n');
  console.log(JSON.stringify(metadata));
})().catch(error => {console.error(error); process.exit(1);});
